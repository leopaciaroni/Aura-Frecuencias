# Aura Ultimate – Bio-Resonance Tool

Estructura del proyecto:

```
/css
/js
/assets
/src
index.html
```

## Deploy Automático con GitHub Pages

1. Sube todo a GitHub.
2. Ve a Settings → Pages.
3. Source: Deploy from branch → main → root.
